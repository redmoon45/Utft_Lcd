# STM32CubeMX and UTFT

STM32CubeMX and UTFT for TFT display.  
In this example I used a ST7789 driver with TFT display with a resolution of 320x240
and a nucleo board 64 with a STM32F103RBT6.
The interface is 8-bit parallel.
In this repository I used the graphic library without a touch screen

[The origin software is here](http://www.rinkydinkelectronics.com)

The screen looks like this picture

![Start](doc/IMG_1283.JPG)

harebit
