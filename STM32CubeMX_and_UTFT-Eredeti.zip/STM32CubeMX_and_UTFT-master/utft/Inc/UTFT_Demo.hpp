/*
 * UTFT_Demo_320x240.hpp
 *
 *  Created on: 03.10.2018
 *      Author: Hare
 */

#ifndef UTFT_DEMO_HPP_
#define UTFT_DEMO_HPP_

void setup(void) ;
void loop(void) ;


#endif /* UTFT_DEMO_HPP_ */
